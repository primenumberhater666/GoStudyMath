# GoStudyMath

## Why ?
As an enjoyer of mathematics, I recognize that mathematics, like many other fields of study, require effective and consistent practice. By designing this application, users will be able to engage in effective practice through the practice questions. 
## Purpose
This application is designed to help users enhance their fundamental mathematical problem-solving skills by offering different practice questions in various concepts such as algebra, combinatorics, and geometry. The application will allow users to generate new variants of a specific type of question, and give immediate feedback after completion of the question. The application will also keep track of some statistics, such as accuracy on a particular concept/type of question and umber of attempts needed for a  question. The user can at any time, view the past variants that they have completed in case they wish to review a previous problem. This type of practice will give users the a tool to identify their strengths and weaknesses and an opportunity for continued practice. 
## Audience

The target audience for this application are those who have an interest in mathematics and want to solidify their understanding of specific concepts, or anyone who wants to learn through practice and repetition. 

## User Stories
- As a user, I want to be able to delete problems from the list of my previously solved problems 
- As a user, I want to be able to view the list of previous problems that I have solved/attempted.
- As a user, I want to be able to generate a new variant of a specific type of quesiton. 
- As a user, I want to be able to view the number of attempts needed for a specific question. 
- As a user, I want to be able to save the list of attempted questions and its associations to file.
- As a user, I want to be able to load my previously-saved list of attempted questions from file.

## Instructions for End User
- Click on the "Add Question" button to generate a new question to add to your list of questions.
- Click on the "Remove Question" button, and then double click on the question you want to delete in order to remove a question from your list.
- Click on the Save or Load question buttons to load user generated questions to/from file. 
- The visual component of the project will be displayed when the application is launched. 

## Phase 4: Task 2 - Console Event Logging: Example
- Sun Mar 30 00:53:01 PDT 2025: LinearEquations1 added to user question list.
- Sun Mar 30 00:53:02 PDT 2025: LinearEquations2 added to user question list.    
- Sun Mar 30 00:53:04 PDT 2025: LinearEquations3 added to user question list.    
- Sun Mar 30 00:53:05 PDT 2025: LinearEquations3 removed from user question list.
- Sun Mar 30 00:53:08 PDT 2025: Average of 0 attempts obtained from user list.   

## Phase 4: Task 3
The general structure of the project is good, however there are some design choices that could've been better made. For instance, I should have made Question.java an abstract class that has both regular and abstract methods, and made the classes for 
each specific questiont type extend that abstract class. This would have made the testing portion of the project much easier, and in a design sense, would have been more efficient. Additionally, I would have split the GUI into multiple classes instead of just one. Although it currently works fine and holds all the desired functionality, it would make the code cleaner and easier to read. Finally, I think that I could have performed abstraction and refactored out new methods that were commonly used in the model package to further improve the efficiency and readability of the code. 